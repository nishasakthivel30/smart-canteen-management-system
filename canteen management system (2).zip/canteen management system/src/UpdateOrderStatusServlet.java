
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/updateorderstatus")
public class UpdateOrderStatusServlet extends HttpServlet {

    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null ||
            !"ADMIN".equalsIgnoreCase(
                (String) session.getAttribute("userRole"))) {

            response.sendRedirect("login.jsp");
            return;
        }

        int orderId = Integer.parseInt(
                request.getParameter("order_id")
        );

        String status = request.getParameter("status");

        String sql =
                "UPDATE orders SET status = ? WHERE order_id = ?";

        try {

            Connection connection =
                    DBConnection.getConnection();

            PreparedStatement statement =
                    connection.prepareStatement(sql);

            statement.setString(1, status);
            statement.setInt(2, orderId);

            statement.executeUpdate();

            statement.close();
            connection.close();

            response.sendRedirect("adminorders");

        } catch (Exception e) {

            e.printStackTrace();

            response.setContentType("text/html;charset=UTF-8");

            response.getWriter().println(
                    "<h2>Failed to update order status!</h2>"
            );

            response.getWriter().println(
                    "<br><a href='adminorders'>Back to All Orders</a>"
            );
        }
    }
}
