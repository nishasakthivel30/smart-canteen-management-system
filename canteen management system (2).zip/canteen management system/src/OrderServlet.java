import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/order")
public class OrderServlet extends HttpServlet {

    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        int foodId =
                Integer.parseInt(request.getParameter("food_id"));

        int quantity =
                Integer.parseInt(request.getParameter("quantity"));

        String pickupTime =
                request.getParameter("pickup_time");

        HttpSession session =
                request.getSession(false);

        if (session == null ||
            session.getAttribute("userId") == null) {

            response.sendRedirect("login.jsp");
            return;
        }

        int userId =
                (Integer) session.getAttribute("userId");

        try {

            Connection connection =
                    DBConnection.getConnection();

            // Get food price and stock
            String foodSql =
                    "SELECT price, stock " +
                    "FROM food_items " +
                    "WHERE food_id = ?";

            PreparedStatement foodStatement =
                    connection.prepareStatement(foodSql);

            foodStatement.setInt(1, foodId);

            ResultSet foodResult =
                    foodStatement.executeQuery();

            if (!foodResult.next()) {

                foodResult.close();
                foodStatement.close();
                connection.close();

                request.setAttribute(
                        "error",
                        "Food item not found!"
                );

                request.getRequestDispatcher(
                        "order.jsp"
                ).forward(request, response);

                return;
            }

            double price =
                    foodResult.getDouble("price");

            int stock =
                    foodResult.getInt("stock");

            // Check stock
            if (quantity > stock) {

                foodResult.close();
                foodStatement.close();
                connection.close();

                request.setAttribute(
                        "error",
                        "Not enough stock available!"
                );

                request.getRequestDispatcher(
                        "order.jsp"
                ).forward(request, response);

                return;
            }

            double totalAmount =
                    price * quantity;

            // Insert order
            String orderSql =
                    "INSERT INTO orders " +
                    "(user_id, total_amount, pickup_time, status) " +
                    "VALUES (?, ?, ?, 'PLACED')";

            PreparedStatement orderStatement =
                    connection.prepareStatement(
                            orderSql,
                            java.sql.Statement.RETURN_GENERATED_KEYS
                    );

            orderStatement.setInt(1, userId);
            orderStatement.setDouble(2, totalAmount);
            orderStatement.setString(3, pickupTime);

            orderStatement.executeUpdate();

            ResultSet keys =
                    orderStatement.getGeneratedKeys();

            int orderId = 0;

            if (keys.next()) {
                orderId = keys.getInt(1);
            }

            // Insert order item
            String itemSql =
                    "INSERT INTO order_items " +
                    "(order_id, food_id, quantity) " +
                    "VALUES (?, ?, ?)";

            PreparedStatement itemStatement =
                    connection.prepareStatement(itemSql);

            itemStatement.setInt(1, orderId);
            itemStatement.setInt(2, foodId);
            itemStatement.setInt(3, quantity);

            itemStatement.executeUpdate();

            // Update stock
            String stockSql =
                    "UPDATE food_items " +
                    "SET stock = stock - ? " +
                    "WHERE food_id = ?";

            PreparedStatement stockStatement =
                    connection.prepareStatement(stockSql);

            stockStatement.setInt(1, quantity);
            stockStatement.setInt(2, foodId);

            stockStatement.executeUpdate();

            // Send order details to success page
            request.setAttribute(
                    "orderId",
                    orderId
            );

            request.setAttribute(
                    "totalAmount",
                    totalAmount
            );

            request.setAttribute(
                    "pickupTime",
                    pickupTime
            );

            request.getRequestDispatcher(
                    "order-success.jsp"
            ).forward(request, response);

            // Close resources
            keys.close();
            itemStatement.close();
            stockStatement.close();
            orderStatement.close();
            foodResult.close();
            foodStatement.close();
            connection.close();

        }  catch (Exception e) {

    e.printStackTrace();

    response.setContentType(
            "text/html;charset=UTF-8"
    );

    response.getWriter().println(
            "<h2>Order failed!</h2>"
    );

    response.getWriter().println(
            "<p>Error: " + e.getMessage() + "</p>"
    );

    response.getWriter().println(
            "<a href='menu'>Back to Menu</a>"
    );
}
    }
}