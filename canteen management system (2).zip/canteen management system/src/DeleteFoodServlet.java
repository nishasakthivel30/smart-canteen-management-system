import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/deletefood")
public class DeleteFoodServlet extends HttpServlet {

    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        int foodId = Integer.parseInt(
                request.getParameter("id")
        );

        String sql =
                "DELETE FROM food_items WHERE food_id = ?";

        try {

            Connection connection =
                    DBConnection.getConnection();

            PreparedStatement statement =
                    connection.prepareStatement(sql);

            statement.setInt(1, foodId);

            statement.executeUpdate();

            statement.close();
            connection.close();

            response.sendRedirect("admin");

        } catch (SQLException e) {

            response.setContentType("text/html;charset=UTF-8");

            if (e.getErrorCode() == 1451) {

                response.getWriter().println(
                        "<h2>Cannot Delete Food Item</h2>"
                );

                response.getWriter().println(
                        "<p>This food item is already used in existing orders.</p>"
                );

                response.getWriter().println(
                        "<p>Existing order history must be preserved.</p>"
                );

            } else {

                e.printStackTrace();

                response.getWriter().println(
                        "<h2>Failed to delete food!</h2>"
                );
            }

            response.getWriter().println(
                    "<br><a href='admin'>Back to Admin Panel</a>"
            );

        } catch (Exception e) {

            e.printStackTrace();

            response.setContentType("text/html;charset=UTF-8");

            response.getWriter().println(
                    "<h2>Failed to delete food!</h2>"
            );

            response.getWriter().println(
                    "<br><a href='admin'>Back to Admin Panel</a>"
            );
        }
    }
}