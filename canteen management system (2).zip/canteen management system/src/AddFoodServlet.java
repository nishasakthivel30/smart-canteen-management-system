import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/addfood")
public class AddFoodServlet extends HttpServlet {

    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String foodName = request.getParameter("food_name");
        String category = request.getParameter("category");
        double price = Double.parseDouble(request.getParameter("price"));
        int stock = Integer.parseInt(request.getParameter("stock"));

        String sql =
                "INSERT INTO food_items " +
                "(food_name, category, price, stock) " +
                "VALUES (?, ?, ?, ?)";

        try {

            Connection connection = DBConnection.getConnection();

            PreparedStatement statement =
                    connection.prepareStatement(sql);

            statement.setString(1, foodName);
            statement.setString(2, category);
            statement.setDouble(3, price);
            statement.setInt(4, stock);

            statement.executeUpdate();

            statement.close();
            connection.close();

            response.sendRedirect("admin");

        } catch (Exception e) {

            e.printStackTrace();

            response.setContentType("text/html;charset=UTF-8");

            response.getWriter().println(
                    "<h2>Failed to add food!</h2>"
            );

            response.getWriter().println(
                    "<a href='addfood.jsp'>Try Again</a>"
            );
        }
    }
}
