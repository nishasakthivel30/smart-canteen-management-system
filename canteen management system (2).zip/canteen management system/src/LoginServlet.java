import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

protected void doPost(
        HttpServletRequest request,
        HttpServletResponse response)
        throws ServletException, IOException {

    String email = request.getParameter("email");
    String password = request.getParameter("password");

    String sql =
            "SELECT user_id, name, email, role " +
            "FROM users " +
            "WHERE email = ? AND password = ?";

    try {

        Connection connection = DBConnection.getConnection();

        PreparedStatement statement =
                connection.prepareStatement(sql);

        statement.setString(1, email);
        statement.setString(2, password);

        ResultSet result = statement.executeQuery();

        if (result.next()) {

            int userId = result.getInt("user_id");
            String name = result.getString("name");
            String userEmail = result.getString("email");
            String role = result.getString("role");

            HttpSession session = request.getSession();

            session.setAttribute("userId", userId);
            session.setAttribute("userName", name);
            session.setAttribute("userEmail", userEmail);
            session.setAttribute("userRole", role);

            request.setAttribute("name", name);
            request.setAttribute("role", role);

            request.getRequestDispatcher("login-success.jsp")
                    .forward(request, response);

        } else {

            request.setAttribute(
                    "error",
                    "Invalid email or password!"
            );

            request.getRequestDispatcher("login.jsp")
                    .forward(request, response);
        }

        result.close();
        statement.close();
        connection.close();

    } catch (Exception e) {

        e.printStackTrace();

        request.setAttribute(
                "error",
                "Login failed!"
        );

        request.getRequestDispatcher("login.jsp")
                .forward(request, response);
    }
}


}
