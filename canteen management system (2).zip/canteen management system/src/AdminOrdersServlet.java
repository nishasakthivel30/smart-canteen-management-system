import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/adminorders")
public class AdminOrdersServlet extends HttpServlet {

    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null ||
            !"ADMIN".equalsIgnoreCase(
                (String) session.getAttribute("userRole"))) {

            response.sendRedirect("login.jsp");
            return;
        }

        String sql =
                "SELECT o.order_id, u.name, f.food_name, " +
                "oi.quantity, o.total_amount, " +
                "o.pickup_time, o.status, o.order_date " +
                "FROM orders o " +
                "JOIN users u ON o.user_id = u.user_id " +
                "JOIN order_items oi ON o.order_id = oi.order_id " +
                "JOIN food_items f ON oi.food_id = f.food_id " +
                "ORDER BY o.order_id DESC";

        try {

            Connection connection =
                    DBConnection.getConnection();

            PreparedStatement statement =
                    connection.prepareStatement(sql);

            ResultSet result =
                    statement.executeQuery();

            request.setAttribute("orders", result);

            request.getRequestDispatcher("adminorders.jsp")
                    .forward(request, response);

        } catch (Exception e) {

            e.printStackTrace();

            response.setContentType("text/html;charset=UTF-8");

            response.getWriter().println(
                    "<h2>Failed to load all orders!</h2>"
            );
        }
    }
}