import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/editfood")
public class EditFoodServlet extends HttpServlet {

    // ================================
    // LOAD FOOD DETAILS
    // ================================
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String idParameter = request.getParameter("id");

        if (idParameter == null || idParameter.trim().isEmpty()) {
            response.sendRedirect("admin");
            return;
        }

        try {

            int foodId = Integer.parseInt(idParameter);

            String sql =
                    "SELECT food_id, food_name, category, price, stock " +
                    "FROM food_items " +
                    "WHERE food_id = ?";

            Connection connection =
                    DBConnection.getConnection();

            PreparedStatement statement =
                    connection.prepareStatement(sql);

            statement.setInt(1, foodId);

            ResultSet result =
                    statement.executeQuery();

            if (result.next()) {

                request.setAttribute(
                        "foodId",
                        result.getInt("food_id")
                );

                request.setAttribute(
                        "foodName",
                        result.getString("food_name")
                );

                request.setAttribute(
                        "category",
                        result.getString("category")
                );

                request.setAttribute(
                        "price",
                        result.getBigDecimal("price")
                );

                request.setAttribute(
                        "stock",
                        result.getInt("stock")
                );

                result.close();
                statement.close();
                connection.close();

                request.getRequestDispatcher(
                        "editfood.jsp"
                ).forward(request, response);

            } else {

                result.close();
                statement.close();
                connection.close();

                response.setContentType(
                        "text/html;charset=UTF-8"
                );

                response.getWriter().println(
                        "<h2>Food item not found!</h2>"
                );

                response.getWriter().println(
                        "<a href='admin'>Back to Admin Panel</a>"
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

            response.setContentType(
                    "text/html;charset=UTF-8"
            );

            response.getWriter().println(
                    "<h2>Unable to load food item.</h2>"
            );

            response.getWriter().println(
                    "<a href='admin'>Back to Admin Panel</a>"
            );
        }
    }


    // ================================
    // UPDATE FOOD DETAILS
    // ================================
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        try {

            int foodId = Integer.parseInt(
                    request.getParameter("food_id")
            );

            String foodName =
                    request.getParameter("food_name");

            String category =
                    request.getParameter("category");

            double price = Double.parseDouble(
                    request.getParameter("price")
            );

            int stock = Integer.parseInt(
                    request.getParameter("stock")
            );

            String sql =
                    "UPDATE food_items " +
                    "SET food_name = ?, " +
                    "category = ?, " +
                    "price = ?, " +
                    "stock = ? " +
                    "WHERE food_id = ?";

            Connection connection =
                    DBConnection.getConnection();

            PreparedStatement statement =
                    connection.prepareStatement(sql);

            statement.setString(1, foodName);
            statement.setString(2, category);
            statement.setDouble(3, price);
            statement.setInt(4, stock);
            statement.setInt(5, foodId);

            statement.executeUpdate();

            statement.close();
            connection.close();

            response.sendRedirect("admin");

        } catch (Exception e) {

            e.printStackTrace();

            response.setContentType(
                    "text/html;charset=UTF-8"
            );

            response.getWriter().println(
                    "<h2>Failed to update food!</h2>"
            );

            response.getWriter().println(
                    "<a href='admin'>Back to Admin Panel</a>"
            );
        }
    }
}