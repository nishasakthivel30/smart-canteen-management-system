import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/myorders")
public class MyOrdersServlet extends HttpServlet {

    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

       HttpSession session = request.getSession(false);

if (session == null || session.getAttribute("userId") == null) {
    response.sendRedirect("login.jsp");
    return;
}

int userId = (Integer) session.getAttribute("userId");

        String sql =
                "SELECT o.order_id, f.food_name, oi.quantity, " +
                "o.total_amount, o.pickup_time, o.status " +
                "FROM orders o " +
                "JOIN order_items oi ON o.order_id = oi.order_id " +
                "JOIN food_items f ON oi.food_id = f.food_id " +
                "WHERE o.user_id = ? " +
                "ORDER BY o.order_id DESC";

        try {

            Connection connection = DBConnection.getConnection();

            PreparedStatement statement =
                    connection.prepareStatement(sql);

            statement.setInt(1, userId);

            ResultSet result = statement.executeQuery();

            request.setAttribute("orders", result);

            request.getRequestDispatcher("myorders.jsp")
                    .forward(request, response);

            result.close();
            statement.close();
            connection.close();

        } catch (Exception e) {

            e.printStackTrace();

            response.getWriter().println(
                    "<h2>Failed to load orders!</h2>"
            );
        }
    }
}
