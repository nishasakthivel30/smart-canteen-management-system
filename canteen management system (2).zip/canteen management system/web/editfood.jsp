<%@ page contentType="text/html;charset=UTF-8" %>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Smart Canteen - Edit Food</title>

    <link rel="stylesheet" href="style.css">

</head>

<body>

    <div class="edit-food-page">

        <div class="edit-food-card">

            <div class="edit-food-icon">
                🍴
            </div>

            <h1>Edit Food Item</h1>

            <p class="edit-food-subtitle">
                Update the food item details below
            </p>


            <%
                String error =
                    (String) request.getAttribute("error");

                if (error != null) {
            %>

                <div class="edit-error">
                    <%= error %>
                </div>

            <%
                } else {
            %>


            <form action="editfood"
                  method="post"
                  class="edit-food-form">

                <!-- Food ID -->

                <input
                    type="hidden"
                    name="food_id"
                    value="<%= request.getAttribute("foodId") %>">


                <!-- Food Name -->

                <div class="edit-field">

                    <label for="food_name">
                        Food Name
                    </label>

                    <input
                        type="text"
                        id="food_name"
                        name="food_name"
                        value="<%= request.getAttribute("foodName") %>"
                        placeholder="Enter food name"
                        required>

                </div>


                <!-- Category -->

                <div class="edit-field">

                    <label for="category">
                        Category
                    </label>

                    <input
                        type="text"
                        id="category"
                        name="category"
                        value="<%= request.getAttribute("category") %>"
                        placeholder="Enter category"
                        required>

                </div>


                <!-- Price -->

                <div class="edit-field">

                    <label for="price">
                        Price
                    </label>

                    <div class="price-input">

                        <span>Rs.</span>

                        <input
                            type="number"
                            id="price"
                            name="price"
                            value="<%= request.getAttribute("price") %>"
                            min="0"
                            step="0.01"
                            placeholder="Enter price"
                            required>

                    </div>

                </div>


                <!-- Stock -->

                <div class="edit-field">

                    <label for="stock">
                        Stock Quantity
                    </label>

                    <input
                        type="number"
                        id="stock"
                        name="stock"
                        value="<%= request.getAttribute("stock") %>"
                        min="0"
                        placeholder="Enter stock"
                        required>

                </div>


                <!-- Buttons -->

                <div class="edit-actions">

                    <button
                        type="submit"
                        class="update-food-button">

                        Update Food

                    </button>


                    <a
                        href="admin"
                        class="cancel-food-button">

                        Cancel

                    </a>

                </div>

            </form>

            <%
                }
            %>

        </div>

    </div>

</body>

</html>