<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Add Food</title>
    <link rel="stylesheet" href="style.css">
  </head>

  <body>
    <h2>Add New Food Item</h2>

    <form action="addfood" method="post">
      <label>Food Name:</label>
      <input type="text" name="food_name" required />

      <br /><br />

      <label>Category:</label>
      <input type="text" name="category" required />

      <br /><br />

      <label>Price:</label>
      <input type="number" name="price" step="0.01" min="0" required />

      <br /><br />

      <label>Stock:</label>
      <input type="number" name="stock" min="0" required />

      <br /><br />

      <button type="submit">Add Food</button>
    </form>

    <br />

    <a href="admin">Back to Admin Panel</a>
  </body>
</html>
