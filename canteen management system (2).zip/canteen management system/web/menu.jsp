<%@ page import="java.sql.ResultSet" %>

<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Smart Canteen Food Menu</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>


<div class="container">

    <div class="admin-header">
        <h1>Smart Canteen Food Menu</h1>
    </div>

    <div class="card">

        <h2>Available Food Items</h2>

        <table>

            <tr>
                <th>Food ID</th>
                <th>Food Name</th>
                <th>Category</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Action</th>
            </tr>

            <%
                ResultSet foodItems =
                    (ResultSet) request.getAttribute("foodItems");

                while (foodItems != null && foodItems.next()) {
            %>

            <tr>

                <td>
                    <%= foodItems.getInt("food_id") %>
                </td>

                <td>
                    <strong>
                        <%= foodItems.getString("food_name") %>
                    </strong>
                </td>

                <td>
                    <%= foodItems.getString("category") %>
                </td>

                <td class="price">
                    Rs.<%= foodItems.getBigDecimal("price") %>
                </td>

                <td>
                    <%= foodItems.getInt("stock") %>
                </td>

                <td>
                   <a href="order.jsp?food_id=<%= foodItems.getInt("food_id") %>">
    <button type="button">Order</button>
</a>
                </td>

            </tr>

            <%
                }
            %>

        </table>

    </div>

</div>

</body>

</html>
