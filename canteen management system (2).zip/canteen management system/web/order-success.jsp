<%@ page contentType="text/html;charset=UTF-8" %>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title>Smart Canteen - Order Successful</title>

    <link rel="stylesheet" href="style.css" />
  </head>

  <body>
    <div class="order-success-page">
      <div class="order-success-card">
        <div class="order-success-icon">✓</div>

        <h1>Order Placed Successfully!</h1>

        <p class="order-success-message">
          Your food order has been placed successfully.
        </p>

        <div class="order-details">
          <div class="order-detail-row">
            <span>Order ID</span>
            <strong> #<%= request.getAttribute("orderId") %> </strong>
          </div>

          <div class="order-detail-row">
            <span>Total Amount</span>
            <strong> Rs.<%= request.getAttribute("totalAmount") %> </strong>
          </div>

          <div class="order-detail-row">
            <span>Pickup Time</span>
            <strong> <%= request.getAttribute("pickupTime") %> </strong>
          </div>

          <div class="order-detail-row">
            <span>Status</span>
            <strong class="order-status"> PLACED </strong>
          </div>
        </div>

        <div class="success-actions">
          <a href="myorders" class="success-button"> View My Orders </a>

          <a href="menu" class="secondary-success-button">
            Back to Food Menu
          </a>
        </div>
      </div>
    </div>
  </body>
</html>
