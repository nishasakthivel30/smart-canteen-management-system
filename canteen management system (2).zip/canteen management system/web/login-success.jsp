<%@ page contentType="text/html;charset=UTF-8" %>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Smart Canteen - Login Successful</title>

    <link rel="stylesheet" href="style.css">

</head>

<body class="success-body">

    <div class="success-page">

        <div class="success-card">

            <!-- Success Icon -->
            <div class="success-icon">
                ✓
            </div>

            <!-- Heading -->
            <h1>Login Successful!</h1>

            <p class="success-message">
                Welcome to Smart Canteen,
                <strong><%= request.getAttribute("name") %></strong>
            </p>

            <p class="success-subtitle">
                You have successfully logged in to your account.
            </p>


            <%
                String role = (String) request.getAttribute("role");

                if ("ADMIN".equalsIgnoreCase(role)) {
            %>

                <!-- Admin -->
                <a href="admin" class="success-button">
                    Open Admin Panel
                </a>

            <%
                } else {
            %>

                <!-- Student -->
                <a href="menu" class="success-button">
                    View Food Menu
                </a>

            <%
                }
            %>


            <div class="success-footer">

                <a href="login.jsp">
                    Back to Login
                </a>

            </div>

        </div>

    </div>

</body>

</html>