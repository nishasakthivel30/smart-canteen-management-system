<%@ page import="java.sql.Connection" %>
<%@ page import="java.sql.DriverManager" %>
<%@ page import="java.sql.PreparedStatement" %>
<%@ page import="java.sql.ResultSet" %>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Smart Canteen - Place Order</title>

    <link rel="stylesheet" href="style.css">
</head>

<body>

    <div class="order-page">

        <div class="order-card">

            <div class="order-icon">
                
            </div>

            <h1>Place Food Order</h1>

            <p class="order-subtitle">
                Select your food and place your order
            </p>

            <form action="order" method="post" class="order-form">

                <div class="order-field">

                    <label for="food_id">
                        Select Food
                    </label>

                    <select name="food_id" id="food_id" required>

                        <option value="">
                            -- Select Food --
                        </option>

                        <%
                            String selectedFoodId =
                                request.getParameter("food_id");

                            try {

                                Class.forName(
                                    "com.mysql.cj.jdbc.Driver"
                                );

                                Connection connection =
                                    DriverManager.getConnection(
                                        "jdbc:mysql://localhost:3307/smart_canteen",
                                        "root",
                                        "root"
                                    );

                                String sql =
                                    "SELECT food_id, food_name, price, stock " +
                                    "FROM food_items WHERE stock > 0";

                                PreparedStatement statement =
                                    connection.prepareStatement(sql);

                                ResultSet result =
                                    statement.executeQuery();

                                while (result.next()) {

                                    int foodId =
                                        result.getInt("food_id");

                                    boolean selected =
                                        selectedFoodId != null &&
                                        selectedFoodId.equals(
                                            String.valueOf(foodId)
                                        );
                        %>

                        <option
                            value="<%= foodId %>"
                            <%= selected ? "selected" : "" %>>

                            <%= result.getString("food_name") %>
                            - Rs.<%= result.getBigDecimal("price") %>
                            (Stock: <%= result.getInt("stock") %>)

                        </option>

                        <%
                                }

                                result.close();
                                statement.close();
                                connection.close();

                            } catch (Exception e) {

                                out.println(
                                    "<p>Unable to load food menu.</p>"
                                );

                                e.printStackTrace();

                            }
                        %>

                    </select>

                </div>


                <div class="order-field">

                    <label for="quantity">
                        Quantity
                    </label>

                    <input
                        type="number"
                        id="quantity"
                        name="quantity"
                        min="1"
                        placeholder="Enter quantity"
                        required>

                </div>


                <div class="order-field">

                    <label for="pickup_time">
                        Pickup Time
                    </label>

                    <input
                        type="time"
                        id="pickup_time"
                        name="pickup_time"
                        required>

                </div>


                <button
                    type="submit"
                    class="place-order-button">

                    Place Order

                </button>

            </form>


            <div class="order-footer">

                <a href="menu">
                    Back to Food Menu
                </a>

            </div>

        </div>

    </div>

</body>

</html>