<%@ page import="java.sql.ResultSet" %>

<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

```
<div class="admin-container">

    <div class="admin-header">
        <h1>Smart Canteen - Admin Panel</h1>
    </div>

    <div class="card">

        <h2>Food Management</h2>

        <div class="actions">
            <a href="addfood.jsp">
                <button type="button">Add Food</button>
            </a>
        </div>

        <table>

            <tr>
                <th>Food ID</th>
                <th>Food Name</th>
                <th>Category</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Action</th>
            </tr>

            <%
                ResultSet foodItems =
                    (ResultSet) request.getAttribute("foodItems");

                while (foodItems != null && foodItems.next()) {
            %>

            <tr>

                <td>
                    <%= foodItems.getInt("food_id") %>
                </td>

                <td>
                    <%= foodItems.getString("food_name") %>
                </td>

                <td>
                    <%= foodItems.getString("category") %>
                </td>

                <td>
                    Rs.<%= foodItems.getBigDecimal("price") %>
                </td>

                <td>
                    <%= foodItems.getInt("stock") %>
                </td>

                <td>

                    <a href="editfood?id=<%= foodItems.getInt("food_id") %>">
                        <button type="button" class="edit-btn">
                            Edit
                        </button>
                    </a>

                    <a href="deletefood?id=<%= foodItems.getInt("food_id") %>"
                       onclick="return confirm('Delete this food item?');">
                        <button type="button" class="delete-btn">
                            Delete
                        </button>
                    </a>

                </td>

            </tr>

            <%
                }
            %>

        </table>

    </div>

    <div class="actions">

        <a href="adminorders">
            <button type="button">
                View All Orders
            </button>
        </a>

        <a href="menu">
            <button type="button" class="update-btn">
                Student Food Menu
            </button>
        </a>

    </div>

</div>
```

</body>

</html>
