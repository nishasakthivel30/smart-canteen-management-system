<%@ page import="java.sql.ResultSet" %>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>All Orders</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <h2>Smart Canteen - All Orders</h2>

    <table border="1" cellpadding="10">

        <tr>
            <th>Order ID</th>
            <th>Student Name</th>
            <th>Food</th>
            <th>Quantity</th>
            <th>Total Amount</th>
            <th>Pickup Time</th>
            <th>Status</th>
            <th>Order Date</th>
        </tr>

        <%
            ResultSet orders =
                (ResultSet) request.getAttribute("orders");

            boolean hasOrders = false;

            while (orders != null && orders.next()) {

                hasOrders = true;
        %>

        <tr>
            <td><%= orders.getInt("order_id") %></td>

            <td><%= orders.getString("name") %></td>

            <td><%= orders.getString("food_name") %></td>

            <td><%= orders.getInt("quantity") %></td>

            <td>
                Rs.<%= orders.getBigDecimal("total_amount") %>
            </td>

            <td><%= orders.getString("pickup_time") %></td>

           <td>

    <form action="updateorderstatus" method="post">

        <input type="hidden"
               name="order_id"
               value="<%= orders.getInt("order_id") %>">

        <select name="status">

            <option value="PLACED"
                <%= "PLACED".equals(orders.getString("status")) ? "selected" : "" %>>
                PLACED
            </option>

            <option value="PREPARING"
                <%= "PREPARING".equals(orders.getString("status")) ? "selected" : "" %>>
                PREPARING
            </option>

            <option value="READY"
                <%= "READY".equals(orders.getString("status")) ? "selected" : "" %>>
                READY
            </option>

            <option value="COMPLETED"
                <%= "COMPLETED".equals(orders.getString("status")) ? "selected" : "" %>>
                COMPLETED
            </option>

        </select>

        <button type="submit">Update</button>

    </form>

</td>
            <td><%= orders.getTimestamp("order_date") %></td>
        </tr>

        <%
            }

            if (!hasOrders) {
        %>

        <tr>
            <td colspan="8">
                No orders found.
            </td>
        </tr>

        <%
            }
        %>

    </table>

    <br>

    <a href="admin">
        <button type="button">Back to Admin Panel</button>
    </a>

</body>

</html>