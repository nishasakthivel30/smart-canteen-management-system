<%@ page import="java.sql.ResultSet" %>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>My Orders</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <h2>My Orders</h2>

    <table border="1" cellpadding="10">

        <tr>
            <th>Order ID</th>
            <th>Food</th>
            <th>Quantity</th>
            <th>Total Amount</th>
            <th>Pickup Time</th>
            <th>Status</th>
        </tr>

        <%
            ResultSet orders =
                (ResultSet) request.getAttribute("orders");

            boolean hasOrders = false;

            while (orders != null && orders.next()) {

                hasOrders = true;
        %>

        <tr>
            <td><%= orders.getInt("order_id") %></td>

            <td><%= orders.getString("food_name") %></td>

            <td><%= orders.getInt("quantity") %></td>

            <td>
                Rs.<%= orders.getBigDecimal("total_amount") %>
            </td>

            <td>
                <%= orders.getString("pickup_time") %>
            </td>

           <td>
    <% 
        String status = orders.getString("status");

        if ("PLACED".equals(status)) {
    %>
         PLACED
    <%
        } else if ("PREPARING".equals(status)) {
    %>
        PREPARING
    <%
        } else if ("READY".equals(status)) {
    %>
         READY
    <%
        } else if ("COMPLETED".equals(status)) {
    %>
        COMPLETED
    <%
        }
    %>
</td>
        </tr>

        <%
            }

            if (!hasOrders) {
        %>

        <tr>
            <td colspan="6">
                No orders found.
            </td>
        </tr>

        <%
            }
        %>

    </table>

    <br>

    <a href="menu">Back to Food Menu</a>

</body>

</html>