<%@ page contentType="text/html;charset=UTF-8" %>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Smart Canteen - Login</title>

    <link rel="stylesheet" href="style.css">
</head>

<body class="login-body">

    <div class="login-page">

        <div class="login-card">

            <!-- Logo -->
            <div class="login-logo">
                🍽️
            </div>

            <!-- Title -->
            <h1>Smart Canteen</h1>

            <p class="login-subtitle">
                Welcome back! Please login to continue.
            </p>

            <!-- Error Message -->
            <%
                String error = (String) request.getAttribute("error");

                if (error != null) {
            %>

                <div class="login-error">
                    <%= error %>
                </div>

            <%
                }
            %>

            <!-- Login Form -->
            <form action="login" method="post" class="login-form">

                <div class="login-field">

                    <label for="email">
                        Email Address
                    </label>

                    <div class="input-box">

                        <span class="field-icon">✉</span>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            placeholder="Enter your email"
                            required>

                    </div>

                </div>


                <div class="login-field">

                    <label for="password">
                        Password
                    </label>

                    <div class="input-box">

                        <span class="field-icon">🔒</span>

                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Enter your password"
                            required>

                    </div>

                </div>


                <button type="submit" class="login-button">
                    Login to Account
                </button>

            </form>


            <!-- Register -->
            <div class="register-section">

                <span>Don't have an account?</span>

                <a href="register.jsp">
                    Create Account
                </a>

            </div>

        </div>

    </div>

</body>

</html>